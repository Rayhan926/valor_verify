import Signup2 from "@views/Signup2";
import React from "react";

const Signup2Page = () => {
  return <Signup2 />;
};

export default Signup2Page;
