import SignIn from "@views/SignIn";
import React from "react";

const SigninPage = () => {
  return <SignIn />;
};

export default SigninPage;
