import ForgotPasssword from "@views/ForgotPasssword";

const ForgotPasswordPage = () => {
  return <ForgotPasssword />;
};

export default ForgotPasswordPage;
