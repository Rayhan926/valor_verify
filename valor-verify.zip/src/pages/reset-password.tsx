import ResetPasssword from "@views/ResetPasssword";
import React from "react";

const ResetPasswordPage = () => {
  return <ResetPasssword />;
};

export default ResetPasswordPage;
