import Signup1 from "@views/Signup1";
import React from "react";

const Signup1Page = () => {
  return <Signup1 />;
};

export default Signup1Page;
